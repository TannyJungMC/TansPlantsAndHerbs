(${input$entity}.isAttackable())
