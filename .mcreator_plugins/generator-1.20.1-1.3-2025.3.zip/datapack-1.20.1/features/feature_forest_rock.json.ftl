{
  "state": ${input$block}
}