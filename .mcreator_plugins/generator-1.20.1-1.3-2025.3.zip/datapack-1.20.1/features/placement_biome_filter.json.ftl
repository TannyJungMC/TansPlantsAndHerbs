{
  "type": "minecraft:biome"
},